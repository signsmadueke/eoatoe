<div data-active-color="white" data-background-color="black" data-image="app-assets/img/sidebar-bg/01.jpg" class="app-sidebar">
        <div class="sidebar-header">
          <div class="logo clearfix"><a href="index" class="logo-text float-left">
              <div class="logo-img"><img src="../assets/images/madueke/icon.png" style="border: 2px solid #fff; border-radius: 20px;" alt="Logo"/></div><span class="text align-middle small">PRAYER M.</span></a><a id="sidebarClose" href="javascript:;" class="nav-close d-block d-md-block d-lg-none d-xl-none"><i class="ft-circle"></i></a></div>
        </div>
        <div class="sidebar-content">
          <div class="nav-container">
            <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
              <li class="nav-item"><a href="index"><i class="icon-home"></i><span data-i18n="" class="menu-title">Dashboard</span></a></li>

                <li class="has-sub nav-item"><a href="#"><i class="icon-book-open"></i><span data-i18n="" class="menu-title">Books</span></a>
                    <ul class="menu-content" style="">
                        <li class=""><a href="books" class="menu-item">All Books</a></li>
                        <li class=""><a href="add_books" class="menu-item">Add Book</a></li>
                        <li class=""><a href="all_free_book" class="menu-item">All Free Book</a></li>
                        <li class=""><a href="add_free_book" class="menu-item">Add Free Book</a></li>
                    </ul>
                </li>

                <li class="has-sub nav-item"><a href="#"><i class="icon-notebook"></i><span data-i18n="" class="menu-title">Devotionals</span></a>
                    <ul class="menu-content" style="">
                        <li class=""><a href="devotionals" class="menu-item">All Devotionals</a>
                        </li>
                        <li class=""><a href="add_devotions" class="menu-item">Add Devotion</a>
                        </li>
                    </ul>
                </li>
            </ul>
          </div>
        </div>
        <div class="sidebar-background"></div>
      </div>






